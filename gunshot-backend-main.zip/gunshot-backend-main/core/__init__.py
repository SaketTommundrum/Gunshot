# app/core/__init__.py
from .config import settings

__all__ = ["settings"]