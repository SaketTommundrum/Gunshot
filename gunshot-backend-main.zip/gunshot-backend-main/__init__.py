# app/__init__.py
# This file can be empty or contain package-level initialization code.